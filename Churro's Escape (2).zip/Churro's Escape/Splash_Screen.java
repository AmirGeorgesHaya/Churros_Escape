import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.*;

/**
 * Write a description of class Splash_Screen here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Splash_Screen extends World
{
    double timeEndScreenCreation = System.currentTimeMillis();
    /**
     * Constructor for objects of class Splash_Screen.
     * 
     */
    public Splash_Screen()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1); 
        showText("Game Programming 1", getWidth()/2, 100);
        showText("Made by: Amir-Georges Haya, Salfi Hawladar and Nathaniel Bitton", getWidth()/2, 150);
        prepare();
    }

    public void act()
    {
        if (System.currentTimeMillis() >= (timeEndScreenCreation + 3000))
        {
            Greenfoot.setWorld(new Start_Screen());        
        } 
    }
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        Logo logo = new Logo();
        addObject(logo,290,287);
    }
}
