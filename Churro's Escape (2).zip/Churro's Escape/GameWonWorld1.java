import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class GameWonWorld1 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class GameWonWorld1 extends World
{

    /**
     * Constructor for objects of class GameWonWorld1.
     * 
     */
    public GameWonWorld1()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1); 
        showWinningTexts("On to the next one!", 100, getHeight()/2);
        GreenfootSound gfs_GameWonWorld1 = new GreenfootSound("Viktor Kraus - Victory!.mp3");
    }
    public void showWinningTexts( String message, int x, int y)
    {
        GreenfootImage bg = getBackground();
         Font font = new Font (50);
         bg.setFont(font);
         bg.setColor (Color.WHITE);
         bg.drawString(message,x,y);
    }
    /*public void started()
    {
       gfs_GameWonWorld1.playLoop();
    
    }
    public void stopped()
    {
       gfs_GameWonWorld1.stop();
    }*/
}
