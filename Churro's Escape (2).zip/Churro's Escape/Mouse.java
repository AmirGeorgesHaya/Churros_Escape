import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Mouse here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

import java.util.*;

public class Mouse extends Actor
{
    /**
     * Act - do whatever the Mouse wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
       move();
       eat();
       key();
       if (isGameWon())
       {
           TransitionToGameWonWorld1();
       }
    }
    public void move()
    {
        if (Greenfoot.isKeyDown("a"))
        {
            setRotation(-180);
            move(4);
            checkObstacle();
            
        }
        if (Greenfoot.isKeyDown("s"))
        {
            setRotation(90);
            move(4);
                        checkObstacle();

        }
        if (Greenfoot.isKeyDown("w"))
        {
            setRotation(-90);
            move(4);
                        checkObstacle();

        }
        if (Greenfoot.isKeyDown("d"))
        {
            setRotation(0);
            move(4);
                        checkObstacle();

        }
        
    }
    
    public void checkObstacle()
    {

    Actor wall = getOneIntersectingObject(Wall.class);
    if (wall!=null)
    {
        move(-5);
    }
}
public void eat()
     {
        Actor Cheese= getOneIntersectingObject(Cheese.class);
         if(Cheese!=null)
         {
              World Level1 = getWorld();
             Level1.removeObject(Cheese);
             
             
         }
         
        }
public void key()
        {
            Actor red_Key= getOneIntersectingObject(Red_Key.class);
            
         if(red_Key!=null)
         {
              World Level1 = getWorld();
             Level1.removeObject(red_Key);
             //List<Actor> wall1_Unlock= getWorld().getObjects(Wall1_Unlock.class);
             //if(wall1_Unlock!=null)
            // {
                Level1.removeObject(getWorld().getObjects(Wall1_Unlock.class).get(0));
                 
             //}
             
         }
        }
public boolean isGameWon()
{
   World world = getWorld();
   if (world.getObjects(Cheese.class).isEmpty())
   {
       return true;
   }
   else
   {
       return false;
   }
}
public void TransitionToGameWonWorld1()
{
    World gameWonWorld1 = new GameWonWorld1();
    Greenfoot.setWorld(gameWonWorld1);
}
}
