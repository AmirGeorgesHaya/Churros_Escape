import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Cat here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Cat extends Actor
{
   public void act()
    {
       move();
       eat();
    }
    public void move()
    {
        if (Greenfoot.isKeyDown("left"))
        {
            setRotation(-180);
            move(3);
            checkObstacle();
            
        }
        if (Greenfoot.isKeyDown("down"))
        {
            setRotation(90);
            move(3);
                        checkObstacle();

        }
        if (Greenfoot.isKeyDown("up"))
        {
            setRotation(-90);
            move(3);
                        checkObstacle();

        }
        if (Greenfoot.isKeyDown("right"))
        {
            setRotation(0);
            move(3);
                        checkObstacle();

        }
        
    }
    
    public void checkObstacle()
    {

    Actor wall = getOneIntersectingObject(Wall.class);
    if (wall!=null)
    {
        move(-10);
    }
}
    public void eat()
     {
        Actor Mouse= getOneIntersectingObject(Mouse.class);
         if(Mouse!=null)
         {
              World Level1 = getWorld();
             Level1.removeObject(Mouse);
             
             
         }
         
        }    
}