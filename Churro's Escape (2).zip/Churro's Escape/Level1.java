import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Level1 extends World
{

    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public Level1()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1); 

        prepare();
    }
    
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {

        Wall1_B wall1_B = new Wall1_B();
        addObject(wall1_B,145,55);
        wall1_B.setLocation(145,55);

        Wall1_Unlock wall1_Unlock = new Wall1_Unlock();
        addObject(wall1_Unlock,60,94);

        Red_Key red_Key = new Red_Key();
        addObject(red_Key,565,372);

        Wall1_U wall1_U = new Wall1_U();
        addObject(wall1_U,348,69);

        wall1_U.setLocation(314,98);
        Wall1_L wall1_L = new Wall1_L();
        addObject(wall1_L,138,353);
        Wall1_M wall1_M = new Wall1_M();
        addObject(wall1_M,338,253);
        Wall1_R wall1_R = new Wall1_R();
        addObject(wall1_R,470,258);
        Cheese cheese = new Cheese();
        addObject(cheese,222,371);

        Cheese cheese2 = new Cheese();
        addObject(cheese2,519,73);
        Cheese cheese3 = new Cheese();
        addObject(cheese3,218,68);
        Cheese cheese4 = new Cheese();
        addObject(cheese4,66,46);
        Cheese cheese5 = new Cheese();
        addObject(cheese5,63,364);
        Cheese cheese6 = new Cheese();
        addObject(cheese6,440,217);
        Cheese cheese7 = new Cheese();
        addObject(cheese7,449,293);
        Cat cat = new Cat();
        addObject(cat,532,191);
        Mouse mouse = new Mouse();
        addObject(mouse,82,236);
        removeObject(cheese2);
        Wall_H wall_H = new Wall_H();
        addObject(wall_H,514,108);
        Wall_V wall_V = new Wall_V();
        addObject(wall_V,472,65);

        Cheese cheese8 = new Cheese();
        addObject(cheese8,525,63);
    }
}
