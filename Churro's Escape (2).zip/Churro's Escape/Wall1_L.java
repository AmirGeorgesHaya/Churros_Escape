import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Wall1_L here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Wall1_L extends Wall
{
    /**
     * Act - do whatever the Wall1_L wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        // Add your action code here.
    }
}
