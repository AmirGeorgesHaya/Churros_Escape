import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Start_Screen here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Start_Screen extends World
{

    /**
     * Constructor for objects of class Start_Screen.
     * 
     */
    public Start_Screen()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1); 
        showText("Press Enter to play", 400, 100);
         Greenfoot.playSound("Pizzaria.wav");
       
    }
    public void act()
    {
      if (Greenfoot.isKeyDown("enter"))
        {
         Greenfoot.setWorld(new Level1());        
         

        } 
       
    }
    
}
